﻿// --------------------------------------------------------------------------
//  Copyright (c) Microsoft Corporation. All rights reserved.
//  Licensed under the MIT License.
// --------------------------------------------------------------------------

namespace Microsoft.Azure.Management.ApiManagement.ArmTemplates.Commands.Executors
{
    public class CreatorExecutor
    {
        // TODO refactor creatorApplicationCommand like ExtractorExecutor
        // Issue: https://github.com/Azure/azure-api-management-devops-resource-kit/issues/623
    }
}
