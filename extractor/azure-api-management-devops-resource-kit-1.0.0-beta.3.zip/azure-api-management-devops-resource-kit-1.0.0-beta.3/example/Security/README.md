# API Management : Security

## OAuth2 & OpenID Connect

APIM supports adding OAuth 2.0 and OpenID Connect servers which can be used to protect APIs with.

The template examples present in this folder are based on the [tutorial](https://docs.microsoft.com/en-us/azure/api-management/api-management-howto-protect-backend-with-aad) present in the docs.
